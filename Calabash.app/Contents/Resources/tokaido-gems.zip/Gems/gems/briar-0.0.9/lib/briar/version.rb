module Briar
  VERSION = '0.0.9'
end
