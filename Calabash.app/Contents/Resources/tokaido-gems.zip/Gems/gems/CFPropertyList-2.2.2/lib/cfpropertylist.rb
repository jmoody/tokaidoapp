# -*- coding: utf-8 -*-

require File.dirname(__FILE__) + '/rbCFPropertyList.rb'


# eof