require 'multi_test'
MultiTest.disable_autorun
