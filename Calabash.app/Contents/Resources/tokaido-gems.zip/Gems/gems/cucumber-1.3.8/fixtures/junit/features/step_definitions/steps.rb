Given /a passing scenario/ do
  #does nothing
end

Given /a failing scenario/ do
  fail
end

Given /a pending step/ do
  pending
end
