Given /^I defined a first step$/ do
end

When /^I define a second step$/ do
end

Then /^I should also have a third step$/ do
end