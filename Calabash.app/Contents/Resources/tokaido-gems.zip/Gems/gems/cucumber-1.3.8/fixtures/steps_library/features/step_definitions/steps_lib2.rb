Given /^I defined a step 4$/ do
end

When /^I create a step 5$/ do
end

Then /^I should be too tired for step 6$/ do
end