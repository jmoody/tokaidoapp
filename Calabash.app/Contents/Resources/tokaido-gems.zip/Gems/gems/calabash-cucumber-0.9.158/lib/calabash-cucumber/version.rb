module Calabash
  module Cucumber
    VERSION = '0.9.158'
    FRAMEWORK_VERSION = '0.9.155'
  end
end
