Then /^I rotate the device to landscape$/ do
  rotate_phone(90)
end

Then /^I rotate the device to portrait$/ do
  rotate_phone(0)
end
