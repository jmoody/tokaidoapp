module Calabash
  module Android
    VERSION = "0.4.11"
  end
end
