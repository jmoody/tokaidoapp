# -*- coding: utf-8 -*-
Given /^My app is running$/ do
#  rotate_phone(0)
end

Given /^my app is running$/ do
#  rotate_phone(0)
end


