module Calabash
  module Common
    VERSION = '0.0.1'
  end
end
