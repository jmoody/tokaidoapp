What?
=====
Share code between Calabash iOS and Android.

License
=======
calabash-common is available under the MIT license. See the LICENSE file for more info.