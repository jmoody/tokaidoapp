# Muxr

A WIP library that exposes a single HTTP connection that it proxies
to multiple endpoints based on their Host.

It is designed for use in Tokaido.

## Installation

Add this line to your application's Gemfile:

    gem 'muxr'

And then execute:

    $ bundle

Or install it yourself as:

    $ gem install muxr

## Usage

This library is not ready for use yet.

## Contributing

1. Fork it
2. Create your feature branch (`git checkout -b my-new-feature`)
3. Commit your changes (`git commit -am 'Add some feature'`)
4. Push to the branch (`git push origin my-new-feature`)
5. Create new Pull Request
